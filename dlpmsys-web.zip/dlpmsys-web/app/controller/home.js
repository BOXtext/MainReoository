'use strict';

module.exports = app => {
  class HomeController extends app.Controller {
    * index() {
      const props = {
        functions: [
          { id: 1, title: 'this is fun 1', url: '/fun1' },
          { id: 2, title: 'this is fun 2', url: '/fun2' }
        ]
      }
      yield this.ctx.render('index', props);
    }
  }
  return HomeController;
}
