'use strict';

module.exports = app => {
  class LoginController extends app.Controller {
    * list() {
      const props = {
        list: [
          { id: 1, title: 'this is news 1', url: '/news/1' },
          { id: 2, title: 'this is news 3', url: '/news/2' }
        ]
      };
      yield this.ctx.render('login', props);
    }
  }
  return LoginController;
}