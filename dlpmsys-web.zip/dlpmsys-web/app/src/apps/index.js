'use strict'
import React from 'react'
import Bundle from '../lib/bundle'
// apps model
import loadPmsys from 'bundle-loader?lazy&name=pmsys!apps/pmsys'
import loadFun2 from 'bundle-loader?lazy&name=fun2!apps/fun2'

module.exports = {
  Pmsys (props) {
    return (
      <Bundle load={loadPmsys}>
        {(Pmsys) => <Pmsys {...props}/>}
      </Bundle>
    )
  },
  Fun2 (props) {
    return (
      <Bundle load={loadFun2}>
        {(Fun2) => <Fun2 {...props}/>}
      </Bundle>
    )
  }
}
