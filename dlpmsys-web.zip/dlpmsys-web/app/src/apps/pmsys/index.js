'use strict'

import React, { Component } from 'react'

import PmLayout from './layout'

export default class Pmsys extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <PmLayout />
    )
  }
}