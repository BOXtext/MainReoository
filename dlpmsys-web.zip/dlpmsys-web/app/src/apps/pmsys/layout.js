'use strict'
import React, { Component } from 'react'
import { Layout, Menu, Breadcrumb, Icon } from 'antd'
const { Content, Sider } = Layout
const { SubMenu } = Menu
import {
  BrowserRouter as Router,
  Route,
  Link,
  NavLink,
  HashRouter
} from 'react-router-dom'

// import page model
import Page1 from './view/page1'
import Page2 from './view/page2'

const Home = () => (
  <p>Pmsys Home</p>
)

const NoMatch = () => (
  <div>
    <p>页面被妖怪吃掉了</p>
    <Link to="/pmsys">回到应用首页</Link>
  </div>
)

const routes = [
  { path: '/',
    exact: true,
    comp: Home
  }, {
    path: '/page1',
    comp: Page1
  }, {
    path: '/page2',
    comp: Page2
  }
]

export default class PmLayout extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <HashRouter>
        <Content style={{ padding: '0 50px' }}>
          <Breadcrumb style={{ margin: '12px 0' }}>
          <Breadcrumb.Item><NavLink to="/">Pmsys</NavLink></Breadcrumb.Item>
          </Breadcrumb>
          <Layout style={{ borderRadius: '6px' }}>
            <Sider width={200} style={{ background: '#fff' }}>
              <Menu
                mode="inline"
                defaultOpenKeys={['sub1']}
                style={{ height: '100%', borderRight: 0 }}
              > 
                <HashRouter basename="/pmsys"/>
                <SubMenu key="sub1" title={<span><Icon type="user" />subnav 1</span>}>
                  <Menu.Item key="1"><Link to="/page1">page1</Link></Menu.Item>
                  <Menu.Item key="2"><Link to="/page2">page2</Link></Menu.Item>
                </SubMenu>
              </Menu>
            </Sider>
            <Content style={{ background: '#fff', padding: 24, margin: 0, minHeight: 1000 }}>
              {
                routes.map((route, index) => (
                  <Route
                    key={index}
                    exact={route.exact}
                    path={route.path}
                    component={route.comp}
                  />
                ))
              }
            </Content>
          </Layout>
        </Content>
      </HashRouter>
    )
  }
}