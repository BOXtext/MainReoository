'use strict'

import React, { Component } from 'react'

export default class Page2 extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <div>page2</div>
    )
  }
}