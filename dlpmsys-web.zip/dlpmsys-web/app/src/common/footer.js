'use strict'

import React, { Component } from 'react'

import { Layout } from 'antd'
const { Footer } = Layout

import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'

export default class DFooter extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <Footer style={{ textAlign: 'center' }}>
        dlmsys ©2017 Created by Danlu Tool Group & FED
      </Footer>
    )
  }
}