'use strict'

import React, { Component } from 'react'

import { Layout, Menu } from 'antd'
const { Header } = Layout

import {
  BrowserRouter as Router,
  Route,
  NavLink
} from 'react-router-dom'

const logoStyle = {
  height: '36px',
  width: '126px',
  background: "url('/public/logo.png')",
  margin: '14px 24px 14px 0',
  float: 'left'
}

export default class DHeader extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <Router>
        <Header style={{ background: '#fff' }}>
          <NavLink to="/">
            <div style={logoStyle} />
          </NavLink>
          <Menu
            mode="horizontal"
            defaultSelectedKeys={['pmsys']}
            style={{ lineHeight: '64px' }}
          >
            <Menu.Item key="pmsys">
              <NavLink to="/pmsys">绩效管理</NavLink>
            </Menu.Item>
          </Menu>
        </Header>
      </Router>
    )
  }
}