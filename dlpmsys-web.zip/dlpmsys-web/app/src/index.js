'use strict'

import React from 'react'
import ReactDom from 'react-dom'
import App from './main'

import 'antd/dist/antd.less'
// import './style';

ReactDom.render(
  <App/>,
  document.getElementById('app')
)
