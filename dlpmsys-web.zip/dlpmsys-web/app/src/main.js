'use strict'
import React, { Component } from 'react'
import {
  BrowserRouter as Router,
  Route,
  HashRouter,
  Link,
  NavLink,
  Switch,
  Redirect
} from 'react-router-dom'
import { Layout, Spin, Menu } from 'antd'
const { Header } = Layout
import DHeader from 'common/header'
import DFooter from 'common/footer'
// load modules
import { Pmsys, Fun2 } from 'apps'

// 临时组件
const NotFound = () => (
  <div>
    <p>页面被妖怪吃掉了</p>
    <Link to="/">回到首页</Link>
  </div>
)

const Hello = () => (
  <p>Hello</p>
)

const RouteView = (props) => (
  <Switch>
    <Route exact path="/" component={Hello}/>
    <Route exact path="/pmsys" component={Pmsys}/>
    <Route exact path="/fun2" component={Fun2}/>
    <Route path='/404' component={NotFound} />
    <Redirect from="*" to="/404"/>
  </Switch>
)

const logoStyle = {
  height: '36px',
  width: '126px',
  background: "url('/public/logo.png')",
  margin: '14px 24px 14px 0',
  float: 'left'
}

// export
export default class App extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <Router>
        <Layout>
          <Header style={{ background: '#fff' }}>
            <NavLink to="/">
              <div style={logoStyle} />
            </NavLink>
            <Menu
              mode="horizontal"
              defaultSelectedKeys={['pmsys']}
              style={{ lineHeight: '64px' }}
            >
              <Menu.Item key="pmsys">
                <NavLink to="/pmsys">绩效管理</NavLink>
              </Menu.Item>
              <Menu.Item key="fun2">
                <NavLink to="/fun2">Fun2</NavLink>
              </Menu.Item>
            </Menu>
          </Header>
          <Spin spinning={false}>
            <Layout>
              <RouteView />
              <DFooter />
            </Layout>
          </Spin>
        </Layout>
      </Router>
    )
  }
}
