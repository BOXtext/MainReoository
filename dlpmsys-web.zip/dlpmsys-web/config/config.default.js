'use strict'

const path = require('path')

module.exports = appInfo => {
  const config = {}

  // should change to your own
  config.keys = appInfo.name + '_1499143088263_9877'

  // add your config here
  config.view = {
    root: [
      path.join(appInfo.baseDir, 'app/view'),
      path.join(appInfo.baseDir, 'path/to/another')
    ].join(','),
    defaultViewEngine: 'nunjucks',
    defaultExtension: '.nj',
    mapping: {
      '.nj': 'nunjucks'
    }
  }
  return config
}
