'use strict';

const path = require('path');

module.exports = {
  entry: './app/src/index.js',
  output: {
    path: path.join(__dirname, 'app', 'public'),
    filename: 'main.bundle.js',
    chunkFilename : '[name].bundle.js',
    publicPath: '/public/'
  },
  resolve: {
    alias: {
      apps: path.join(__dirname, 'app', 'src', 'apps'),
      common: path.join(__dirname, 'app', 'src', 'common'),
      lib: path.join(__dirname, 'app', 'src', 'lib')
    }
  },
  module: {
    rules: [{
      test: /\.js?$/,
      exclude: /node_modules/,
      use: {
        loader: 'babel-loader',
        options: {
          presets: ['react', 'latest'],
          plugins: [['import', { libraryName: 'antd', style: true }]]
        }
      }
    }, {
      test: /\.less$/,
      loaders: ['style-loader', 'css-loader', 'less-loader']
    }, {
      test: /\.(eot|woff|woff2|ttf|svg|png|jpg)$/,
      loader: 'url-loader?limit=30000&name=[name]-[hash].[ext]'
    }]
  },
  plugins: [
    
  ]
}
